# agentlint

**Your `AGENTS.md` rules are followed most of the time. agentlint makes the important ones a gate, and keeps a committed record of every exception.**

Coding agents write the mechanical part well. What goes wrong is judgment: a payment call without an idempotency key, a dropped column without a backfill, a fallback that hides a failure, an unbounded read that was fine in the fixture. A prompt asks the agent to remember. A linter can only say "always wrong". An AI reviewer says something different on every run. And when the diff is large, the human approves because the tests are green.

agentlint covers that gap:

- **A deterministic trigger.** A rule matches a code shape or normalized Git change. The engine uses no model, network, or wall clock. Repository-authored imperative detectors are trusted code; `rules test` replays their fixtures and rejects differing findings.
- **Your standard, at the moment it applies.** The finding carries the written standard, its checks, and permitted examples, so the agent does not rely on context recall.
- **A gate the agent cannot talk past.** Each finding stays open until the code changes or someone records an acceptance with a concrete reason. You decide per rule whether an agent may accept or only a human.
- **A reviewable record.** Acceptances live in `.agentlint/acceptances.jsonl`, bound to the exact evidence. They show in the pull request diff, and they expire when the code materially changes. It is an `eslint-disable` that needs a reason, an authority, and a new review when the code moves.
- **A review built for it.** Humans decide in a keyboard-first local UI or in pull request threads, with the code, the standard, and the agent's proposal side by side.

An open gate means every current finding in the reported scan scope has a compatible recorded decision. It does not prove that the judgment was correct or that unconfigured concerns were reviewed.

agentlint ships no rules and prescribes no agent harness. Repositories and plugin packages own their standards, detectors, and policy.

## The model

```text
repository evidence -> deterministic detector -> finding
finding + exact compatible acceptance -> gate open
finding without acceptance             -> gate closed
```

A rule is the composition of:

- a durable, revisioned `standard`;
- a versioned `detector`;
- a repository-owned `binding` containing scope, options, and `agent` or `human` authority.

`state` rules judge current repository structure. `change` rules judge normalized before/after evidence from the Git merge base to the complete working tree.

## Install

The short path is to let your coding agent do it. The package ships agent skills in `node_modules/@aurelienbbn/agentlint/skills` ([TanStack Intent](https://tanstack.com/intent) discovers them; any agent can read them):

```text
Install @aurelienbbn/agentlint and follow its setup skill
(node_modules/@aurelienbbn/agentlint/skills/agentlint/setup/SKILL.md).
```

The `setup` skill initializes the config, suggests plugins that match your dependencies, calibrates before enforcing, and installs the Claude Code or Codex hook. By hand:

```bash
pnpm add -D @aurelienbbn/agentlint
pnpm agentlint init
```

Every command accepts `--help`. `--rule` may be repeated or comma-separated.

`init` creates `.agentlint/config.ts` and ignores ephemeral selector and acceptance-transaction files. Commit the config and `.agentlint/acceptances.jsonl` when it exists.

## Turn a repeated correction into a rule

The best first rule is a correction you or a teammate has already made twice. Tell your agent:

```text
Use the agentlint rule-advisor skill. I keep correcting this in review: <the correction>.
```

The `rule-advisor` skill first checks whether a linter, a type, or a test is the better tool. If judgment is needed, it writes the standard, a pattern detector, and activation and silence fixtures, then calibrates the rule against your real code with `rules scan --review` before anything is enforced. A pattern rule is about twenty lines, and you review it like any other code.

Keep the rule only when the review work it saves exceeds its interruptions and maintenance. [The pilot worksheet](../../docs/review-pilot.md) provides a small-team evaluation without telemetry or a central service.

## Start from a plugin

Rule packages are ordinary npm packages that export `defineRule` values and presets. Compose explicit package exports:

```bash
pnpm agentlint init --preset "<rule-package>#<preset-export>"
pnpm agentlint rules test
pnpm agentlint rules scan --review
pnpm agentlint next --format json
```

Install compatible plugin packages before running their rules. `init` prints a `pnpm add` command to adapt to your package manager; it does not install or execute them and preserves an existing config. Repeat `--preset` to compose packages. Each value is a package name plus `#` and an exported configuration. Repositories own the resulting imports and can narrow scopes or select individual rules.

Use only a package and export that are available from the repository's configured registry or workspace. The engine contains no catalog, default rules, or plugin dependency. A rule package should declare the compatible agentlint range as a peer dependency and document the judgment its preset introduces.

## Wire it into your agent

An instruction is a request. A hook is a checkpoint. Copy the adapter that ships with the `setup` skill and commit it:

```bash
mkdir -p .agentlint/hooks
cp node_modules/@aurelienbbn/agentlint/skills/agentlint/setup/agentlint-gate.mjs .agentlint/hooks/
```

Claude Code (`.claude/settings.json`) and Codex (`.codex/hooks.json`, in a trusted project) use the same shape:

```json
{
  "hooks": {
    "Stop": [{ "hooks": [{ "type": "command", "command": "node .agentlint/hooks/agentlint-gate.mjs stop" }] }]
  }
}
```

The agent cannot finish a turn while `check --all` reports unresolved findings: the findings and the next action come back as feedback. A finding that only a human can close interrupts once and then lets the turn end, so the agent proposes its work and hands over to `agentlint review` instead of looping. The `setup` skill also documents an optional per-edit `PostToolUse` hook. The adapter is one short script over the CLI exit code and owns no gate semantics.

For any other agent, put one line in `AGENTS.md`: run `agentlint check --all` before finishing. Either way, a local hook is feedback; the required [CI check](#ci) is the gate.

## Adopt gradually

agentlint has no warning level, deliberately. A warning is what an agent learns to ignore, and a finding that nobody must answer leaves no record. Adoption is controlled by what you bind and where you enforce it:

1. **Calibrate without enforcing.** `rules scan --review` lists the matches of a rule, creates no acceptances, and blocks nothing. Label matches, then fix the detector, scope, and guidance.
2. **Bind a small scope.** Start `binding.include` at the directories under active work and widen it later. For a concern that should only apply to new work, write a `change` rule: it judges the diff from the merge base, so existing code creates no obligations.
3. **Run the gate as feedback.** `check` in a hook or a non-required CI job reports findings while nothing depends on its exit code.
4. **Enforce last.** When `check --all` exits 0, mark the CI check as required.

Do not open a gate by bulk-accepting findings with a generic reason. Work the queue with `agentlint next`, or narrow the binding until the queue is one you intend to answer.

## Define a state rule

```ts
import { defineConfig, defineRule } from "@aurelienbbn/agentlint";

const boundedReads = defineRule({
  lifecycle: "state",
  standard: {
    id: "data/bounded-reads",
    revision: 1,
    title: "Production reads are bounded",
    guidance: {
      standard: "Reads that scale with production data have an explicit bound or pagination contract.",
      checks: ["A hard limit, cursor, or proven finite dataset can satisfy the standard."],
      examples: [{ label: "Explicit bound", code: "db.users.findMany({ take: 50 })" }],
    },
  },
  detector: {
    id: "prisma/find-many-without-take",
    version: 1,
    match: {
      pattern: "$DB.findMany($$$ARGS)",
      where: { notHas: "take: $_" },
      message: "$DB has no explicit bound.",
    },
    fixtures: {
      mustReport: ["db.users.findMany({})"],
      mustStaySilent: ["db.users.findMany({ take: 50 })"],
    },
  },
  binding: {
    id: "data/bounded-reads",
    authority: "agent",
    reviewEpoch: 1,
    include: ["src/**/*.ts"],
    exclude: ["**/*.test.ts"],
  },
});

export default defineConfig({ rules: [boundedReads] });
```

Patterns are parsed code shapes, not text searches. `$NAME` captures one node, `$_` matches one node, and `$$ARGS` matches sibling sequences. A placeholder that appears twice must capture the same code: `$A === $A` matches `x === x` and not `x === y`. When several matches of one rule apply to the same node, the node is reported once, under the first declared match. A `where` constraint searches the matched code; a property constraint such as `take: $_` also accepts the shorthand `{ take }` and does not look inside the value of another property. A raw tree-sitter `query` can designate its result with `@match`. `createOnce({ context, options })` is the imperative escape hatch for stateful and repository-wide detectors.

Fixtures are focused evidence. `mustReport` proves activation. `mustStaySilent` protects valuable boundaries. They need not enumerate every possible mistake, and their code is never sent to the agent as normal guidance.

### Sources and references

`standard.source` records the durable policy or decision that explains why the standard exists. It accepts a URL (`{ type: "url", href }`) or a repository file (`{ type: "file", path }`). It is provenance, not detector input, and changing it does not change what a rule matches.

`standard.guidance.refs` adds material that can help make the current judgment. A reference is either a browser URL (`{ type: "url", href }`) or an agent skill (`{ type: "skill", id }`). References do not activate a rule and do not open a gate.

The review UI opens safe HTTP(S) references in a new tab. Repository-file sources and skill identifiers remain typed targets in the copied finding context; the browser does not pretend it can resolve them. This keeps the contract useful to agents without turning an unresolved identifier into a broken link.

During an attached review, the localhost server detects supported editors and file explorers. The first **Open in…** action asks which detected application to use and remembers that choice locally. The browser sends only the finding identifier and selected allowlisted application; the server resolves and validates the repository path before opening it. Detached artifacts contain neither machine paths nor application capabilities.

## Define a change rule

Use change rules when the concern is the operation, not merely the resulting source.

```ts
const destructiveMigration = defineRule({
  lifecycle: "change",
  standard: {
    id: "database/destructive-migrations",
    revision: 1,
    title: "Destructive schema changes receive human review",
    guidance: {
      standard: "A destructive migration includes a verified backfill, rollback, and deployment sequence.",
      examples: [{ code: "// Expand, backfill, verify, then contract in a later deployment." }],
    },
  },
  detector: {
    id: "sql/destructive-operation",
    version: 1,
    detect({ context }) {
      for (const file of context.change.files) {
        for (const hunk of file.hunks) {
          const destructive = hunk.lines.find(
            (line) => line.kind === "addition" && /drop\s+(table|column)/i.test(line.content),
          );
          if (!destructive) continue;
          context.report({
            key: `${file.path}:destructive-schema`,
            lineageKey: `${file.path}:destructive-schema`,
            file: file.path,
            message: "This change introduces a destructive schema operation.",
            evidence: { operation: destructive.content.trim() },
            excerpt: destructive.content,
            startLine: hunk.newStart,
          });
        }
      }
    },
    fixtures: {
      mustReport: [{ before: {}, after: { "migration.sql": "DROP TABLE legacy_users;" } }],
      mustStaySilent: [{ before: {}, after: { "migration.sql": "CREATE TABLE users (id int);" } }],
    },
  },
  binding: {
    id: "database/destructive-migrations",
    authority: "human",
    include: ["migrations/**"],
  },
});
```

The engine compares the selected ref's merge base with the current working tree. The evidence includes committed branch changes, staged and unstaged edits, renames, deletions, and untracked files. `--base <ref>` is explicit; otherwise agentlint detects an upstream or conventional main branch and fails clearly if no valid base exists.

## Run the gate

```bash
pnpm agentlint rules test
pnpm agentlint check                 # changed files plus all change rules
pnpm agentlint check --all           # complete state scan and safe stale cleanup
pnpm agentlint check --base main
pnpm agentlint check --format jsonl
```

Exit code `1` means unresolved findings. Exit code `2` means invalid usage, configuration, or evidence. Local and CI checks have identical gate semantics.

For an agent-authority finding:

```bash
pnpm agentlint explain 1
pnpm agentlint accept 1 --reason "The containing function restricts this read to the verified finite lookup dataset."
```

For a human-authority finding, open the review UI or use the explicit human entry point:

```bash
pnpm agentlint review
pnpm agentlint approve 1 --reason "Backfill and restore drill linked in the migration."
```

An agent acceptance cannot satisfy a human binding. A human acceptance can satisfy either authority. Architectural,
privacy, destructive-operation and public-contract rules normally use human authority: an agent may attach a proposal,
but cannot ratify its own contextual conclusion.

When an agent has done the work but cannot decide, it records a proposal so the reviewer sees the change next to the evidence:

```bash
git diff src/migrations/2026-06-drop-legacy-flag.ts > /tmp/backfill.diff
pnpm agentlint propose 6 --summary "Added an idempotent backfill before the drop." --diff-file /tmp/backfill.diff
```

`.agentlint/proposals.jsonl` holds one proposal per exact finding identity. A proposal is context for a human; it never opens a gate.

## Resume review work

`agentlint next --format json` returns a version 1 handoff: one unresolved finding, full available source, detector excerpt, guidance, explicit related file paths, required authority, remaining count, scan scope and command argument arrays. Its ordering is stable by file, line and exact identity. An agent-authority finding offers acceptance; a human-authority finding offers a proposal and human review. Required reasons and summaries are supplied separately by the caller.

`next` uses a complete scan by default and the same acceptance compatibility and stale cleanup as `check --all`. `--rule` narrows the scan and reports partial coverage. Every invocation rescans; a cleared filtered queue does not replace a complete checkpoint. Exit codes are 0 for clear scope, 1 for unresolved work and 2 for invalid configuration or evidence. Decode JSON with `NextResult` from `@aurelienbbn/agentlint/contract`.

## Acceptance identity

`.agentlint/acceptances.jsonl` contains current state, not an event log. An acceptance opens a gate only when all material identity agrees:

- standard id and revision;
- detector id and version;
- binding id and material binding digest;
- repository-controlled review epoch, when configured;
- fingerprint scheme, version, and evidence digest;
- sufficient authority.

State fingerprints (version 3) include the containing file syntax, the structural occurrence, optional reported evidence, and the contents of explicit `binding.dependencies`. Whitespace between syntax nodes retains acceptance; literal and comment contents remain material. Changes to the containing file structure invalidate it, even outside the matched call. This is intentionally conservative: changes elsewhere in a busy file may require another review. Unicode source values stay exact.

`binding.reviewEpoch` is an optional positive integer controlled by the repository. Increment it when otherwise unchanged
decisions need a fresh review because an assumption, policy period or ownership context changed. The epoch participates in
finding identity and invalidates compatible acceptances without consulting wall-clock time; agentlint itself remains
deterministic and never expires decisions merely because a date passed.

For a state binding, when a justification relies on another file, add its exact normalized repository-relative path to `binding.dependencies`, for example `["src/http/pagination.ts"]`. Dependencies are required inputs, not globs. Their contents are available as `context.dependencies[path]`. Include them in repository fixtures too. A dependency change triggers a full scan of the binding, even if its matched file did not change. The engine does not infer runtime or transitive dependencies. Change detectors define their supporting evidence explicitly through `report({ evidence })`; `binding.dependencies` is rejected for change rules.

Imperative state detectors default to repository scans. A detector that is independent for each file can declare `scan: "file"`. Node wrappers are valid during their file visitor only. In `after()`, use captured plain data rather than retaining syntax nodes. `context.report` accepts optional material JSON `evidence`, a unique stable `key`, and `relatedFiles` selected from declared binding dependencies. Change findings may select related files from their normalized change set. Related sources travel with review artifacts and appear as collapsible reading context; they do not become material evidence unless the detector also reports them in `evidence`.

This pre-v1 draft supports the current format only and provides no migration or backward-compatibility layer. Regenerate artifacts and review findings again after a breaking change. Version fields remain part of the gate contract: unsupported evidence can never satisfy a finding. Change detectors own their material `evidence`; changing it invalidates acceptance. Optional lineage can show a prior reason after invalidation, but it never opens the new gate.

Complete scans remove dead acceptances. Partial scans preserve anything they did not examine.

```bash
pnpm agentlint acceptances list
pnpm agentlint acceptances clean
```

## Review and calibration

`agentlint review` serves the packaged FoldKit SPA on loopback with a session token. The **Queue** lists everything that still needs a decision, grouped by file, with the agent's proposal (summary and diff) shown next to the code when one exists. The **Decisions** view lists what is already accepted, by whom and when, so a human can audit agent acceptances and request a correction. Requesting changes revokes a compatible acceptance and closes its gate. Finishing the review can hand requested changes back to the agent while those findings remain unresolved. Both feed the same handoff the coding agent receives when the review finishes.

The UI is keyboard-first: `J`/`K` move, `A` accepts, `R` requests changes, `E` opens the editor, `C` copies context, `/` searches, `F` opens filters, `1`/`2` switch views, `X` dismisses a toast, `?` lists everything. Requesting changes needs no text; accepting needs a reason unless an agent proposal exists, in which case the proposal becomes the reason.

Calibration exercises a detector without creating acceptance state:

```bash
pnpm agentlint rules scan --rule data/bounded-reads --review
```

Use it on an existing codebase to label matches as applies, does not apply, or unsure. Refine the rule, binding, guidance, and fixtures from the temporary feedback.

## Related and independent review

The list's Filters menu offers Related grouping. Findings are connected by their containing files and explicit state-binding dependencies, including transitive shared connections. A detector can narrow that reading set with `relatedFiles`; the UI packages and shows those sources next to the primary code. It does not infer callers, common causes or runtime dependencies. Groups change navigation only. Every finding still needs its own compatible decision.

Independent review is an optional session-only presentation mode. It hides acceptance reasons, prior lineage reasons and proposals, including in copied context. Write an assessment before revealing the prior material; the assessment becomes the editable reason for the next decision. Keyboard decision actions follow the same restriction. This reduces anchoring; it is not a confidentiality or authorization boundary, and the original data remains in the browser payload. Enable it before starting the review of a finding.

## Record delayed outcomes

Immediate gate results do not establish long-term maintainability. When later work supplies evidence—a useful interception,
unnecessary review, escaped concern, corrective change, rollback or incident—attach it to the current finding:

```bash
pnpm agentlint outcomes record 4 --kind corrective_change --reference commit:abc123 \
  --note "A second owner drifted from the policy."
pnpm agentlint outcomes list
pnpm agentlint outcomes list --format json
```

`.agentlint/outcomes.jsonl` is a committed observational record. Outcomes never open or close a gate. Reusing the same
finding, kind and reference updates the note; distinct outcomes remain. The summary groups observations by rule and kind
so repositories can keep, refine or remove rules using delayed evidence instead of treating a green gate as proof.

## Measure detector calibration

Calibration shows saved applies / does-not-apply / unsure labels and the applicability rate over decided labels. A does-not-apply label requires a category: scope, detector, guidance, valid exception or other. Notes add context. Unsubmitted edits do not enter the report.

Download a version 1 calibration JSON report during the session or on completion. Save successive exports under distinct filenames and combine reports from the same repository:

```bash
pnpm agentlint rules calibration before.json after.json --format json
```

Reports are observational artifacts, never acceptance inputs. Aggregation counts each exact finding once; later input files replace labels for duplicate evidence. Standards, detector versions and material bindings stay separate. The summary includes non-applicability categories and lineages with at least two distinct observed invalidated identities. It cannot reconstruct unobserved history or prove detector recall. An absence of decided labels produces a null rate, not a perfect score. API consumers can use the schemas and pure helpers at `@aurelienbbn/agentlint/calibration`.

These workflows take conceptual inspiration from desloppify by Peter O'Malley. Their implementation and contracts are original to agentlint; no code or instructions were copied.

## Detached CI review

CI must not wait for a browser. It can emit a portable artifact while keeping the gate closed:

```bash
pnpm agentlint check --all --review-output artifacts/agentlint-review.json
```

Download the artifact, then open it locally:

```bash
pnpm agentlint review --from artifacts/agentlint-review.json
```

The detached UI stages decisions in the browser. It exports requested changes as Markdown and decisions as JSONL. Every accepted or revoked decision includes the exact source snapshot shown to the reviewer. Import rescans the repository and rejects a decision when that source changed. Requesting changes on an existing acceptance also targets the exact identity, reviewed reason, and acceptance timestamp, so import rejects the revocation if the decision has since been replaced. Revocations are applied to the current store, not retained as another persisted finding outcome. Bring reviewed acceptances back through the validation path:

```bash
pnpm agentlint acceptances import agentlint-acceptances.jsonl
pnpm agentlint check --all
```

Review artifacts use version 3 and contain each source file once, with the scan scope, executed bindings, and inspected files. Regenerate version 1 or 2 artifacts. The artifact uses the original check snapshot, including transient prior reasoning, rather than scanning again.

Import re-runs the repository detectors. Decisions whose finding changed, disappeared, or no longer has compatible authority are rejected.

When the artifact comes from the agentlint GitHub action, `pnpm agentlint pr <number>` downloads it through the `gh` CLI and opens it in one step; `--artifact-only` prints the extracted path instead.

## CLI reference

```text
agentlint check [files...] [--all] [--base ref] [--rule id]
                [--format text|jsonl] [--review-output path]
agentlint accept <selector> --reason "..." [--base ref]
agentlint approve <selector> --reason "..." [--base ref]
agentlint propose <selector> --summary "..." [--diff-file path] [--base ref]
agentlint explain <rule-id|selector>
agentlint review [--base ref] [--mode review|calibration] [--from artifact]
                 [--port number] [--no-open]
agentlint pr <number> [--repo owner/name] [--artifact-only] [--port number] [--no-open]
agentlint next [--base ref] [--rule id] [--format text|json]
agentlint rules calibration <reports...> [--format text|json]
agentlint rules list|test|scan
agentlint acceptances list|clean|import
agentlint outcomes record <selector> --kind <kind> --reference "..." --note "..."
agentlint outcomes list [--format text|json]
agentlint init
```

The selector cache under `.agentlint/.cache/` only maps short run-local numbers such as `1` back to full finding identities. It is disposable and must not be committed.

## CI

The [GitHub action](../../action/README.md) runs the same gate on every pull request. It creates the `agentlint` check run with one annotation per finding, keeps a summary comment up to date, and opens one review thread per finding on the diff. A collaborator with write access replies `/agentlint approve <reason>` in a thread to record human authority; the action commits the acceptance on the branch as that person and updates the check without re-running the workflow. Mark the `agentlint` check as required and the gate is enforced.

```yaml
name: agentlint
on:
  pull_request:
  issue_comment: { types: [created] }
  pull_request_review_comment: { types: [created] }
concurrency:
  group: agentlint-${{ github.event.pull_request.number || github.event.issue.number }}
  cancel-in-progress: false
jobs:
  gate:
    if: github.event_name == 'pull_request'
    runs-on: ubuntu-latest
    permissions: { contents: read, pull-requests: write, checks: write }
    steps:
      - uses: actions/checkout@v5
        with: { fetch-depth: 0 }
      - uses: actions/setup-node@v5
        with: { node-version: 22 }
      - uses: aurelienbobenrieth/agentlint/action@v0.1.5
  command:
    if: github.event_name != 'pull_request' && startsWith(github.event.comment.body, '/agentlint')
    runs-on: ubuntu-latest
    permissions: { contents: write, pull-requests: write, checks: write }
    steps:
      - uses: actions/checkout@v5
        with: { fetch-depth: 0 }
      - uses: actions/setup-node@v5
        with: { node-version: 22 }
      - uses: aurelienbobenrieth/agentlint/action@v0.1.5
```

`fetch-depth: 0` is required because change rules use the merge base. The action runs `npx @aurelienbbn/agentlint@<version>` and resolves the package for `.agentlint/config.ts` itself, so no install step is needed unless the config imports third-party rule packages (`install: true`). Pull requests from forks run with a read-only token: they get annotations and the review artifact, not comments or approvals. See the [action README](../../action/README.md) for every input and output, and `dry-run` for testing.

Without the action, any CI can run the gate and upload the artifact:

```yaml
- run: npx @aurelienbbn/agentlint rules test
- run: npx @aurelienbbn/agentlint check --all --base "origin/${{ github.base_ref }}" --review-output artifacts/agentlint-review.json
- uses: actions/upload-artifact@v4
  if: failure()
  with: { name: agentlint-review, path: artifacts/agentlint-review.json }
```

Open an uploaded artifact locally with `agentlint pr <number>` (see [Detached CI review](#detached-ci-review)).

## Integration boundary

The engine contains no MCP server, harness protocol, GitHub bot, or provider SDK. Integrations call the CLI and read its exit code. The hook adapter in the `setup` skill is a copyable script of that kind, not an engine surface:

| Exit code | Meaning                                             |
| --------- | --------------------------------------------------- |
| `0`       | Every current finding has a compatible acceptance.  |
| `1`       | One or more findings are unresolved.                |
| `2`       | The command, configuration, or evidence is invalid. |

A harness can continue after a non-blocking `check` during a work loop, but it must report unresolved findings before it finishes. Use `check --all` as the hard gate at a checkpoint and in CI.

Provider adapters (pull-request comments, ownership routing, signed human authority) belong outside the engine. They must preserve the same current-finding and acceptance semantics, and they are added only when the CLI and artifact contract cannot provide the required experience.

## Public API

`@aurelienbbn/agentlint` exports what a rule or config author needs and nothing else:

- `defineConfig` and `defineRule`, with the `AgentlintConfig`, `AgentlintRule`, `StateRule`, `ChangeRule`, `RuleBinding`, `RuleStandard`, `Guidance`, `RuleMatch`, and `Visitors` types.
- `RuleContext` (`absolutePath`, `path`, `source`, `report`) and `ChangeRuleContext` for detector implementations, plus `AgentlintNode` and `TreeSitterNodeType`.
- The change evidence schemas (`ChangeSet`, `ChangedFile`, `ChangeHunk`, `ChangeLine`, `FileSnapshot`, `ChangeBaseline`), `FindingRecord`, `OutcomeKind`, and `OutcomeRecord` as runtime values, so a consumer can construct or decode them.
- Tagged errors: `RuleDefinitionError`, `ConfigError`, `PatternError`, `ParserError`.

`@aurelienbbn/agentlint/testing` exports the promise-based helpers `testRuleFixtures`, `testRuleOnSource`, `testRuleOnSources`, and `testRuleOnChange`, plus `normalizeChangeFixture`, `FixtureReport`, and `FixtureFailure`. The public API does not require consumers to construct engine services or import Effect. `testRuleOnSources` accepts `[path, source]` pairs, including all declared dependencies.

Compact change fixtures use an actual line comparison with three context lines. For very large fixtures or precise rename evidence, supply an explicit `ChangeSet`. Fixtures test detector activation; file scope is calibrated against a repository with `rules scan`.

The package intentionally exports no bundled standards, detectors, rules, or presets.

## Scan and storage guarantees

State parsing supports JavaScript, TypeScript, TSX, and JSON. Change detectors consume Git evidence for other file types too. Full state enumeration skips `node_modules`, `.git`, `dist`, `coverage`, `.cache`, and `.agents`. Repository ignores apply before directory traversal. Explicit directories expand recursively. Missing explicit paths, failed reads, incomplete or unsupported syntax, paths outside the repository and invalid bindings fail the scan. A partial scan never qualifies for complete stale cleanup.

Acceptance, proposal and outcome updates use an exclusive cross-process lock and atomic file replacement. A failure before atomic replacement preserves the previous destination. After replacement, readers see the complete new file. Power-loss durability and network filesystem semantics are not certified. A transaction holds the corresponding `.agentlint/*.lock` for milliseconds. Locks carry an ownership token and a writer only releases its own lock. A lock is never stolen based on age because a paused process may still resume and write; after an abrupt process death, remove the orphaned lock manually. The CLI fails clearly after a bounded wait. Git retains historical decisions and outcomes. Lineage can explain invalidation from the pre-cleanup snapshot; it is not a persistent history service.

## Security boundary

Local human authority is accountability, not cryptographic identity. A process with repository write access can edit configuration and acceptance files. Git review makes those changes visible. Provider-backed proof can be added later without changing the core gate semantics.

## License

[MIT](LICENSE)
